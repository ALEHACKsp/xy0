#include "CHandle.h"
#include "CEntity.h"
#include "IClientEntity.h"
#include "IClientEntityList.h"


