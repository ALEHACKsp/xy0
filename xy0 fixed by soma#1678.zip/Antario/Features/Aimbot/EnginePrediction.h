#pragma once

namespace engine_prediction
{
    void RunEnginePred();
    void EndEnginePred();

	extern float curtime;
	extern float frametime;
}