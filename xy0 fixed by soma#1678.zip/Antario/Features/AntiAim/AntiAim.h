#pragma once
#include "..\..\Utils\GlobalVars.h"
#include "..\..\SDK\CGlobalVarsBase.h"

class AntiAim
{
public:
	void OnCreateMove();

private:

};
extern AntiAim g_AntiAim;